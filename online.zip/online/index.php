<?php
	header("location: login-rsud-krt-setjonegoro-wonosobo.html");
?>